var m=(e=>(e.Admin="Admin",e.Manager="Manager",e.Employee="Employee",e))(m||{});export{m as a};
